# -*- coding: utf-8 -*-
"""
Created on Mon May 11 07:33:14 2020

@author: Benjamin
"""

import subprocess
import sys
import os
import pandas as pd
from numpy import array as arr

def nodeText():
    return
def compText():
    return

class component():
    def __init__(self,t,name,label,value,d,scale,here,starts,tos):
        nodes = circuitMaker().nodes
        lines = circuitMaker().lines
        dx = circuitMaker().dx
        dy = circuitMaker().dy

        self.type = t
        self.name = name
        self.label = label
        self.value = value
        self.scale = scale

        #print(starts,tos)
        diffs = tos - starts
        if d != '':
            if d == 'up' or d=='u':
                self.up = here
                self.down = here + arr([0,-scale*dy])
                self.mid = here + arr([0,-0.5*scale*dy])
                self.left = here + arr([-0.5*scale*dx,-0.5*scale*dy])
                self.right = here + arr([0.5*scale*dx,-0.5*scale*dy])
                self.start = self.down
                self.end = here
            elif d=='down' or d=='d':
                self.up = here + arr([0,scale*dy])
                self.down = here 
                self.mid = here + arr([0,0.5*scale*dy])
                self.left = here + arr([-0.5*scale*dx,0.5*scale*dy])
                self.right = here + arr([0.5*scale*dx,0.5*scale*dy])
                self.start = self.up
                self.end = here
            elif d == 'left' or d=='l':
                self.up = here + arr([0.5*scale*dx,0.5*scale*dy])
                self.down = here + arr([0.5*scale*dx,-0.5*scale*dy])
                self.mid = here + arr([0.5*scale*dx,0])
                self.left = here 
                self.right = here + arr([scale*dx,0])
                self.start = self.right
                self.end = here
            elif d=='right' or d=='r':
                self.up = here + arr([-0.5*scale*dx,0.5*scale*dy])
                self.down = here + arr([-0.5*scale*dx,-0.5*scale*dy])
                self.mid = here + arr([-0.5*scale*dx,0])
                self.left = here + arr([-scale*dx,0])
                self.right = here 
                self.start = self.left
                self.end = here
            self.up = tuple(self.up)
            self.down = tuple(self.down)
            self.mid = tuple(self.mid)
            self.left = tuple(self.left)
            self.right = tuple(self.right)
            self.start = tuple(self.start)
            self.end = tuple(self.end)
        elif diffs.sum() != 0:
            dist = tos - starts
            self.up = starts + dist/2 + arr([0,dist[1]/2])
            self.down = starts + dist/2 + arr([0,-dist[1]/2])
            self.mid = starts + dist/2
            self.left = starts + dist/2 + arr([-dist[1]/2,0])
            self.right = starts + dist/2 + arr([dist[1]/2,0])
            self.start = starts
            self.end = tos
            #print('positions: \n',self.up,'\n',self.down,'\n',self.mid,'\n',self.left,'\n',self.right,'\n',self.start,'\n',self.end,'\n')
                       
            self.up = tuple(self.up)
            self.down = tuple(self.down)
            self.mid = tuple(self.mid)
            self.left = tuple(self.left)
            self.right = tuple(self.right)
            self.start = tuple(self.start)
            self.end = tuple(self.end)
            
        #print(label,'\nUp: \t',self.up,'\nDown: \t',self.down,'\nMid: \t',self.mid,'\nLeft: \t',self.left,'\nRight: \t',self.right,'\nStart: \t',self.start,'\nEnd: \t',self.end,'\n')
        #print('Comp create: ',label,self.start,self.end)
        #print('bingo',here)


class Node:
    def __init__(self, val=None):
        self.val = val
        self.nextval = None
        
class SLinkedList:
    def __init__(self):
        self.headval = None

    def __iter__(self):
        node = self.headval
        while node:
            yield node
            node = node.nextval

    def __getitem__(self,index):
        node = self.headval
        for i in range(index):
            node = node.nextval
        return node.val
   
    def __setitem__(self,index,obj,value):
        self.node[index].val.obj = value

    def getNode(self,find):
        node = self.headval
        while node is not None:
            if node.val.name == find or node.val.label == find:
                return node.val
            else:
                node = node.nextval

    def getPos(self,find,pos):
        node = self.headval
        while node is not None:            
            if node.val.name == find or node.val.label == find:
                #if node.val.label != '': print('getPos: ',node.val.label, node.val.end,find,pos)
                if pos == 'up':
                    return node.val.up

                elif pos=='down':
                    return node.val.down

                elif pos=='mid':
                    return node.val.mid

                elif pos=='left':
                    return node.val.left

                elif pos=='right':
                    return node.val.right

                elif pos=='start':
                    return node.val.start

                elif pos=='end':
                    return node.val.end

                elif pos.lower()=='g' or pos.lower()=='b':
                    return node.val.G

                elif pos.lower()=='d' or pos.lower()=='c':
                    return node.val.D

                elif pos.lower()=='s' or pos.lower()=='e':
                    return node.val.S
            else:
                node = node.nextval

        sys.exit('Could not find given name.')
        
    # Function to add newnode
    def AtEnd(self, newdata):
        NewNode = Node(newdata)
        if self.headval is None:
            self.headval = NewNode
            return
        laste = self.headval
        while(laste.nextval):
            laste = laste.nextval
        #if NewNode.val.label != '': print('node: ',NewNode.val.end)
        laste.nextval=NewNode
        
    def listLen(self,):
        val = self.headval
        cnt = 0
        while val is not None:
            cnt += 1
            val = val.nextval
        return cnt

    def replace_node(self, index, data):
        self.locate(index)
        self.current_node.data = data    

class circuitMaker:
    def __init__(self,dx = 20,dy = 20,O = (0,0),scale=25.4,path = r'C:\Users\Benjamin\texmf\tex\latex\circuit_macros\circuit_macros',fname = 'ex0.m4cm'):
        self.fname = fname
        self.dest = path + r'\\' + fname 
        self.init = ['.PS','include(pstricks.m4)','scale = {}'.format(scale),'cct_init','dx = {}'.format(dx),'dy = {}'.format(dy),'O: {}'.format(O)]
        self.dx = dx
        self.dy = dy
        self.path = path
        self.here = arr(O)
        self.map = []           # 0 = up, 1 = down, 2= left, 3= right
        self.nav = [0,0,0,0]    # up, down, left, right        
        self.components = []
        self.comps = SLinkedList()
        self.nodes = ['dot','ground']
        self.lines = ['resistor','ebox','inductor','capacitor','fuse','lswitch','line','gap','lamp','pvcell','thermocouple','heater','reed','ttmotor','diode']
        
    def draw(self,caption=None,lang=''):
        if caption != None:
            cap = '\caption{' + caption +'}'
        else:
            cap = ''
        latex = [r'\documentclass[dvips]{article}',r'\usepackage{pstricks}',r'\usepackage[utf8]{inputenc}',r'\usepackage{times}',r'\pagestyle{empty}',r'\begin{document}',r'\begin{figure}[hbt]',r'\begin{center}',r'\include{ex0}',cap,r'\end{center}',r'\end{figure}',r'\end{document}']
        with open(self.path + r'\Example_0.tex', 'w') as file:
            for line in latex:
                file.write(line+'\n')         
        
        comps = self.init + self.components + ['.PE']
        with open(self.dest, 'w') as file:
            for line in comps:
                file.write(line+'\n')         
            
    def pdf(self,fname = 'ex0.m4cm'):
        #path = 'set m4path'
        path = 'set ' + str(os.path.dirname(os.path.abspath(__file__)))
        #args = [h,path,'m4 ex0.m4cm > ex0.pic','dpic -p ex0.pic > ex0.tex','latex -quiet Example_0.tex','dvips -q Example_0.dvi','ps2pdf Example_0.ps']
        args = [path,
                '{} ex0.m4cm > ex0.pic'.format(self.path + r'\m4.exe'),
                '{} -p ex0.pic > ex0.tex'.format(self.path + r'\dpic.exe'),
                'latex -quiet Example_0.tex',
                'dvips -q Example_0.dvi',
                'ps2pdf Example_0.ps']
        for arg in args:
            subprocess.run(arg,stdout=subprocess.PIPE, shell=True)

    def jpg(self,fname = 'ex0.m4cm'):
        path = 'set ' + str(os.path.dirname(os.path.abspath(__file__)))
        h = 'm4 --version'
        #args = [h,path,'m4 ex0.m4cm > ex0.pic','dpic -p ex0.pic > ex0.tex','latex -quiet Example_0.tex','dvips -q Example_0.dvi','ps2pdf Example_0.ps']
        args = [h,path,'{} ex0.m4cm > ex0.pic'.format(self.path + r'\m4.exe'),'{} -p ex0.pic > ex0.tex'.format(self.path + r'\dpic.exe'),'latex -quiet Example_0.tex','dvips -q Example_0.dvi','ps2jpg Example_0.jpg']
        for arg in args:
            subprocess.run(arg,stdout=subprocess.PIPE, shell=True)

    def getRGB(self,color):
        if type(color) == type(list()):
            if len(color) == 3:
                return color
            else:
                sys.exit('To define a color you must either provide a name for the color or a list of 3 numbers in range from 0 to 1.')
        elif type(color) == type(''):
            if color.lower() == 'black':     
                return [0,0,0]
            elif color.lower() == 'red':        return [1,0,0]
            elif color.lower() == 'green':      return [0,1,0]
            elif color.lower() == 'blue':       return [0,0,1]
            elif color.lower() == 'cyan':       return [0,1,1]
            elif color.lower() == 'magenta':    return [1,0,1]
            elif color.lower() == 'yellow':     return [1,1,0]
            elif color.lower() == 'grey':       return [0.5,0.5,0.5]


    def add(self,comp,d='',start='',at='',to='',t='',name = '',label = '',label_pos = 'center',color = [0,0,0],i = None,scale=1,sign=None,value=None,crossover=True,variable=False):       
        # ================= Variables =================
        direction = d
        starts = start.split('.')
        ats = at.split('.')
        tos = to.split('.')
 
        start = starts[0]
        at = ats[0]
        to = tos[0]
        pos = ''
        a = b = move = arr([0,0])
        rgb = self.getRGB(color)

        # ================= Qualifying input =================
        #if (start != '' and len(starts) > 0) or (to != '' and len(tos) >0) and (to != 'O' or start != 'O'):
        #    sys.exit('Relative position to the desired component label must be provided if not start or end point is "O". Options are "up","down","mid","left","right","start","end".')
            
        
        # ================= String manipulation =================
        # LABEL
        if label != '' or sign != None:
            if sign == 'motor' or sign == 'm':
                sign1='+';sign2='-'
            elif sign == 'generator' or sign == 'g':
                sign1='-';sign2='+'
            else:
                sign1='';sign2=''
            if label_pos == 'center':
                lab = 'llabel({},{},{});'.format(sign1,label,sign2)
        else:
            lab = ''
            
        # CURRENT
        if i != None:
            I = 'b_current({});'.format(i)
        else:
            I = ''
        if t != '' and type(str('')) == type(t):
            t = ','+t

        # ================= Positioning =================
        # DIRECTION ONLY
        if d != '':
            if d == 'up' or d=='u':
                move = arr([0,scale*self.dy])
                self.map = 0;
                self.nav[0] += 1*scale

            elif d=='down' or d=='d':
                move = arr([0,-scale*self.dy])
                self.map = 1;
                self.nav[1] += 1*scale
            elif d == 'left' or d=='l':
                move = arr([-scale*self.dx,0])
                self.map = 2;
                self.nav[2] += 1*scale

            elif d=='right' or d=='r':
                move = arr([scale*self.dx,0])
                self.map = 3;
                self.nav[3] += 1*scale

            self.dim = [max(self.nav[0],self.nav[1]),max(self.nav[2],self.nav[3])]

        # ================= Move cases =================
        # DIRECTION ONLY
        if d != '' and start == '' and to == '':
            self.here = arr(self.here) + arr(move)            
            if d == 'up' or d=='u':
                d= d+'_ {}'.format(scale*self.dy)
            elif d=='down' or d=='d':
                d= d+'_ {}'.format(scale*self.dy)
            elif d == 'left' or d=='l':
                d= d+'_ {}'.format(scale*self.dx)
            elif d=='right' or d=='r':
                d= d+'_ {}'.format(scale*self.dx) 
        # TO
        elif start == '' and  d == '' and to != '':
            if to == 'O':
                b = arr((0,0))
                self.here = arr(tuple((0,0)))
            else:
                self.here = arr(self.comps.getPos(tos[0],tos[1]))
                b = arr(self.comps.getPos(tos[0],tos[1]))            
            d = ' to ' + str(tuple(b))                

        # START -> TO
        elif start != '' and to != '':
            if start == 'O':
                a = arr((0,0))
            else:
                a = arr(self.comps.getPos(starts[0],starts[1]))
            if to == 'O':
                b = arr((0,0))
                self.here = arr(tuple((0,0)))
            else:
                self.here = arr(self.comps.getPos(tos[0],tos[1]))
                b = arr(self.comps.getPos(tos[0],tos[1]))            
            d = ' from ' + str(tuple(a)) + ' to ' + str(tuple(b))
        # START WITH DIRECTION
        elif start != '' and to == '' and d != '':
            if start == 'O':
                a = arr((0,0))
                self.here = move
            else:
                self.here = arr(self.comps.getPos(starts[0],starts[1])) + move
                a = arr(self.comps.getPos(starts[0],starts[1]))
            d = d+'_ {} from '.format(self.dx*scale) + str(tuple(a))
        # AT
        elif at != '':
            d = ' from '+ at + pos

        # ================= Appending component =================
        # Linked list
        #print(label,a,type(a))
        C = component(t,name,label,value,direction,scale,self.here,a,b)
        #if comp in self.lines: print('C: ',C.label,C.start,C.end)
        self.comps.AtEnd(C)
        # String list for printing to m4cm doc
        if comp == 'line':
            if crossover == True:
                item = 'rgbdraw({},{},{},crossover({}{}));{}{}'.format(rgb[0],rgb[1],rgb[2],d,t,lab,I)
            else:
                item = '{} {};{}{}'.format(comp,d,t,lab,I)
        else:            
            if variable == True:
                item = 'rgbdraw({},{},{},variable({}({}{})));{}{}'.format(rgb[0],rgb[1],rgb[2],comp,d,t,lab,I)
            else:
                item = 'rgbdraw({},{},{},{}({}{}));{}{}'.format(rgb[0],rgb[1],rgb[2],comp,d,t,lab,I)
        #self.components.append(comp + lab + I)
        self.components.append(item)
        
cm = circuitMaker()
cm.add('dot')
cm.add('source',d='up',t='AC',label='V_s')
cm.add('inductor',d='right',label='L',scale=1.5)
cm.add('capacitor',d='down',label='C')
cm.add('line',start='L.end',d='right')
cm.add('resistor',d='down',label='R1',color='blue')
cm.add('line',to='O',scale=2.5)
cm.add('resistor',start='C.up', d='up',label='R2')
cm.add('resistor',start='V_s.end',to='C.down',label='R3')
cm.add('resistor',d='down',label='R4')
cm.add('line',start='O',d='down',scale=2,color='cyan')
cm.add('line',start='R4.end',d='left',scale=3,color='red')
cm.add('inductor',d='up')
cm.add('inductor',d='up')
cm.add('inductor',d='up')
cm.add('inductor',d='right',color='blue')
cm.add('inductor',d='down',color='yellow')

cm.draw()
cm.pdf()





"""
.PS

include(pstricks.m4)

scale=25.4

cct_init

dx = 12.5
dy = 12.5

O: (0,0)

Vs: source(up_ dy from O,S); llabel(,\mathbf{V}_s,)
L:  inductor(right_ 2*dx,,3,,dimen_/5); llabel(,jX_s,); b_current(i)
Zl: ebox(down_ to (Here.x,O.y));        llabel(,\mathbf{Z}_l,)
    line to O
    dot
    ground
    
.PE

"""
