"""
@author:    Benjamin Vilmann, 
            Stud. B.Eng. Electrical Energy Technology
            @ Technical University of Denmark
"""
#from pycm import circuitMaker
cm = circuitMaker()
cm.add('ground')
cm.add('source',d='up',label='V_0')
cm.add('ebox',d='right',label='Z_\phi')
cm.add('line',d='down',scale=0.5)
cm.add('ground')


cm.draw()
cm.pdf()



