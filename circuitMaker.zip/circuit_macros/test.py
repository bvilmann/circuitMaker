"""
@author:    Benjamin Vilmann, 
            Stud. B.Eng. Electrical Energy Technology
            @ Technical University of Denmark
"""
from pycm import circuitMaker

cm = circuitMaker()
cm.add('dot')
cm.add('source',d='up',t='AC',label='V_s')
cm.add('inductor',d='right',label='jX_L',i='i_{L}',scale=1.5)
cm.add('capacitor',d='down',label='jX_C',i='i_C')
cm.add('line',start='jX_L.end',d='right')
cm.add('resistor',d='down',label='R_{load}',i='i_{load}')
cm.add('line',d='left',scale=2.5)
cm.add('ground')
cm.drawCircuit()
cm.pdf()


